#!/bin/bash

OSD=$(mpc current)
notify-send -i ~/.icons/top.png "$OSD"